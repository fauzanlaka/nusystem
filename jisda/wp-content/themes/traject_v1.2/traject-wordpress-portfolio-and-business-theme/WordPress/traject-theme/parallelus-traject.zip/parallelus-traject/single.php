<?php get_header();

	// Get options for page
	//-----------------------------------------------------------
		
	// title
	$pageTitle = get_the_title();
	
	// breadcrumbs
	$hideBreadcrumbs = get_post_meta($post->ID, 'breadcrumbOff', true);

	// sub-title
	$subTitle = get_post_meta($post->ID, 'subTitle', true);
	
	// page icon
	$pageIcon = get_post_meta($post->ID, 'pageIcon', true);
	if ( $pageIcon == 'custom' ) {
		$pageIcon = '<img src="'. get_post_meta($post->ID, 'pageIcon_custom', true) .'" width="128" height="128" alt="Post" />';	// Custom
	} elseif ( $pageIcon == '' ) {
		$pageIcon = '<img src="'. $themePath .'images/icons/post.png" width="128" height="128" alt="Post" />';	// Default
	} else {
		$pageIcon = '<img src="'. $pageIcon .'" width="128" height="128" alt="Post" />';	// Selected Icon
	}
	
	
	// The content loop
	//-----------------------------------------------------------
	if (have_posts()) : 
	while (have_posts()) : the_post();
	
		?>
		<div id="PageOverlay">
			<div id="PageOverlayContent">
					<div class="contentArea">
						<h1 class="pageTitle"><?php echo $pageTitle; ?></h1>
						<div class="pageIcon"><?php echo $pageIcon;?></div>
					</div>
			</div>
		</div> <!-- END id="PageOveraly" -->


		<div id="Showcase">
			<div id="ShowcaseContent">
				<div class="contentArea">
					<h2 class="pageTagLine">
						<?php
						if ( $subTitle != '' ) :
							echo $subTitle;
						else : ?>
							<span class="postComments"><?php comments_popup_link('Comments', '1 comment', '% comments'); ?></span>
							<?php 
							// post date
							if (get_theme_var('postsShowDate') !== '' ) {
								echo '<span class="postDate">'. get_the_time('M') .' '. get_the_time('j') .', '. get_the_time('Y') .'</span>';
								echo '&nbsp; | &nbsp;';
							} 
							// Author name
							if (get_theme_var('postsShowAuthor') !== '' ) { ?>
								<span class="postAuthor">Posted by <?php the_author_posts_link(); ?> in </span>
								<?php 
							} ?>
							<span class="postCategories"><?php the_category(', ') ?></span>
							<?php 
						endif; ?>
					</h2>
				</div> <!-- END class="contentArea" -->
			</div> <!-- END id="ShowcaseContent" -->
		</div> <!-- END id="Showcase" -->


		<div id="MainPage">
			<div id="MainPageContent">
				<div class="contentArea">
										
					<div class="two_third">

						<div class="breadcrumbs" <?php  if ($hideBreadcrumbs) { echo 'style="background: none;"'; } ?>>
							<?php  if (!$hideBreadcrumbs) { show_breadcrumbs(); } ?>
						</div>
					
						<?php the_content('More Information...'); ?>
							
						<!-- End of Content -->
						<div class="clear"></div>
	
						<!-- Post Extras -->
						<div class="postFooter">
								<?php 
								if ( function_exists('the_tags') ):
									if (get_the_tags()): ?>
									<p class="postTags">
										<strong>Tags:</strong> &nbsp;
										<?php echo the_tags('', ', ', '');?>
									</p>
									<?php
									endif; 
								endif; ?>
							<?php edit_post_link('Edit','<p class="postEdit">','</p>'); ?>
						</div>
						
						<!-- End of Content -->
						<div class="clear"></div>
					
						<!-- Post Comments -->
						<div class="userComments" id="comments">
							<?php comments_template('', true); ?>
						</div>
					
						<?php get_pagination(); ?>
	
						<!-- End of Content -->
						<div class="clear"></div>
	
					</div> <!-- end  <div class="two-thirds"> -->
		<?php 
	endwhile; 
	endif; ?>
										
<?php get_sidebar(); ?>

<?php get_footer(); ?>
<?php get_header(); 
	
	// Get options for portfolio page ($portfolioID set in checkPageType() found in addon-functions.php)
	//--------------------------------------------------------------------------------------------------------------
	
	$options = get_theme_var('portfolioSettings');	// retrieves settings array from database

	// get portfolio id
	$flipped_ids = array_flip(get_theme_var('portfolioPages'));
	$portfolioID = $flipped_ids[$post->ID];
	
	$pageTitle = get_the_title($post->ID);
	$imageLayout = $options[$portfolioID.'_Layout'];
	$useCategories = $options[$portfolioID.'_Categories'];
	$pageItems = $options[$portfolioID.'_Items'];
	$linkOption = $options[$portfolioID.'_Open'];
	$excLeng = ($imageLayout == 'portrait') ? 49 : 17;
	
	// breadcrumbs
	$hideBreadcrumbs = get_post_meta($post->ID, 'breadcrumbOff', true);

	// sub-title
	$subTitle = get_post_meta($post->ID, 'subTitle', true);
	if ( $subTitle == '' ) {
		$subTitle = $options[$portfolioID.'_SubTitle']; // from portfolio setup
	}
	
	// page icon
	$pageIcon = get_post_meta($post->ID, 'pageIcon', true);
	if ( $pageIcon == 'custom' ) {
		$pageIcon = '<img src="'. get_post_meta($post->ID, 'pageIcon_custom', true) .'" width="128" height="128" alt="'. $pageTitle .'" />';	// Custom
	} elseif ( $pageIcon == '' ) {
		$pageIcon = '<img src="'. $themePath .'images/icons/camera.png" width="128" height="128" alt="'. $pageTitle .'" />';	// Default
	} else {
		$pageIcon = '<img src="'. $pageIcon .'" width="128" height="128" alt="'. $pageTitle .'" />';	// Selected Icon
	}
	
	?>
		<div id="PageOverlay">
			<div id="PageOverlayContent">
					<div class="contentArea">
						<h1 class="pageTitle"><?php echo $pageTitle; ?></h1>
						<div class="pageIcon"><?php echo $pageIcon;?></div>
					</div>
			</div>
		</div> <!-- END id="PageOveraly" -->

		<div id="Showcase">
			<div id="ShowcaseContent">
				<div class="contentArea">
					<h2 class="pageTagLine"><?php echo $subTitle; ?></h2>
				</div>
			</div>
		</div> <!-- END id="Showcase" -->

		<div id="MainPage">
			<div id="MainPageContent">
				<div class="contentArea">
					
					<div class="breadcrumbs" <?php  if ($hideBreadcrumbs) { echo 'style="background: none;"'; } ?>>
						<?php  if (!$hideBreadcrumbs) { show_breadcrumbs(); } ?>
					</div>
					
					<?php 
					// check for page content
					query_posts('page_id='.$post->ID);
					
					if (have_posts()) : 
					while (have_posts()) : the_post(); 
						if (get_the_excerpt() != '') {
							// Print content from the page
							the_content('More Information...');
						}
					endwhile;
					endif;
					?>
					
				</div>
				

				<!-- End of Content -->
				<div class="clear"></div>
				
				<div class="contentArea">
					
					<!-- Gallery/Portfolio -->
					<div class="portfolioArea <?php if ($imageLayout == 'portrait') { echo 'portfolioStyle-2'; }?>">

					<?php 
					// Categories to include
					if ( is_array($useCategories) ) {
						$portfolioCategories = implode(',',$useCategories );
					}
					// Posts per page
					$itemsPerPage = ($pageItems <= 0) ? '9' : $pageItems;
					
					// query the selected items
					query_posts('cat='.$portfolioCategories.'&posts_per_page='.$itemsPerPage.'&paged='.$paged);
					
					if (have_posts()) : 
					while (have_posts()) : the_post(); 
					
						
						// get the post image
						$primaryMedia = get_post_meta($post->ID, "_imageOriginal", true);
						$portfolioImg = ($imageLayout == 'portrait') ? showImage(180, 235, 'image', 'medium') : showImage(250, 160, 'image', 'medium');
						
						// check for video
						if ( $portfolioImg['hasvideo'] ) {
							$is_video = true;	// this isn't an image, so it must be a video
							$rel = '';
						} else {
							// ok, it's an image
							$fullsizeImg = showImage(640, 480, '', 'original');
							$is_video = false;
							$rel = 'rel="portfolio"';
						}
						
						// image link and class info
						$imgClass = ($imageLayout == 'portrait') ? 'imgTall' : 'imgMedium';
						if ($linkOption == 'post') {
							$linkHref = get_permalink();
							$class = 'class="'. $imgClass .' item-preview iconDoc"';
						} else {
							if ($is_video) {
								$linkHref = $primaryMedia;
								$class = 'class="zoom '. $imgClass .' item-preview iconPlay"';
							}else {
								$linkHref = $fullsizeImg['src'];
								$class = 'class="zoom '. $imgClass .' item-preview iconZoom"';
							}
						}

			
						?>
						<div class="portfolioItem">
							<a href="<?php echo $linkHref; ?>" <?php echo $class; ?> title="<?php the_title(); ?>" <?php echo $rel; ?>>
								<?php echo $portfolioImg['full']; ?>
								<span class="imgFrame"></span>
							</a>
							<div class="portfolioDescription">
								<h4><?php the_title(); ?></h4>
								<p><?php echo customExcerpt(get_the_content(), $excLeng); ?></p>
								<a href="<?php echo get_permalink(); ?>" class="boxLink">More Information...</a>
							</div>
						</div>
						<?php
						
					endwhile;
					endif;
					?>						

						<!-- End of Content -->
						<div class="clear"></div>
					
					</div> <!-- end "portfolioArea" -->

					<!-- End of Content -->
					<div class="clear"></div>
					
					<?php get_pagination(); ?>
					
<?php get_footer(); ?>
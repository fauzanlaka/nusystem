<?php get_header(); ?>

			<div id="PageOverlay">
				<div id="PageOverlayContent">
						
						<div class="contentArea">
							<!-- Title / Page Headline -->
							<h1 class="pageTitle">Error 404</h1>
							<div class="pageIcon"><img src="<?php bloginfo('template_url');?>/images/icons/alert.png" width="128" height="128" alt="Alert" /></div>
						</div>
	
				</div> <!-- END id="PageOverlayContent" -->
			</div> <!-- END id="PageOveraly" -->
	
			<div id="Showcase">
				<div id="ShowcaseContent">
					<div class="contentArea">
						<h2 class="pageTagLine">Page could not be found.</h2>
					</div> <!-- END class="contentArea" -->
				</div> <!-- END id="ShowcaseContent" -->
			</div> <!-- END id="Showcase" -->
	
	
		<div id="MainPage">
			<div id="MainPageContent">
				<div class="contentArea">
				
					<!-- Page Content -->

					<br />
					<br />
					<br />
					
					<h3><?php 
						if (get_theme_var("custom404") != '') {
							echo stripslashes(get_theme_var("custom404"));
						} else {
							echo 'Sorry, the page you are looking for wasn\'t found.'; 
						}
					?></h3>
					
					<br />
					<br />
					<br />


					<!-- End of Content -->
					<div class="clear"></div>
	

<?php get_footer(); ?>
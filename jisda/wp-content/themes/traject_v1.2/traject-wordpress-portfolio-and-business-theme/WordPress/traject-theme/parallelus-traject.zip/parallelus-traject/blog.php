<?php get_header(); 
	
	// Get options for blog page ($blogID set in checkPageType() found in addon-functions.php)
	//--------------------------------------------------------------------------------------------------------------
	
	$options = get_theme_var('blogSettings');	// retrieves settings array from database

	// get blog id
	$flipped_ids = array_flip(get_theme_var('blogPages'));
	$blogID = $flipped_ids[$post->ID];
	$pageTitle = get_the_title($post->ID);
	$excludeCategories = $options[$blogID.'_Exclude'];
	
	// breadcrumbs
	$hideBreadcrumbs = get_post_meta($post->ID, 'breadcrumbOff', true);

	// sub-title
	$subTitle = get_post_meta($post->ID, 'subTitle', true);
	if ( $subTitle == '' ) {
		$subTitle = $options[$blogID.'_SubTitle'];	// from blog setup
	}
	
	// page icon
	$pageIcon = get_post_meta($post->ID, 'pageIcon', true);
	if ( $pageIcon == 'custom' ) {
		$pageIcon = '<img src="'. get_post_meta($post->ID, 'pageIcon_custom', true) .'" width="128" height="128" alt="'. $pageTitle .'" />';	// custom
	} elseif ( $pageIcon == '' ) {
		$pageIcon = '<img src="'. $themePath .'images/icons/post.png" width="128" height="128" alt="'. $pageTitle .'" />';	// Default
	} else {
		$pageIcon = '<img src="'. $pageIcon .'" width="128" height="128" alt="'. $pageTitle .'" />';	// Selected Icon
	}

	?>
		<div id="PageOverlay">
			<div id="PageOverlayContent">
					<div class="contentArea">
						<h1 class="pageTitle"><?php echo $pageTitle; ?></h1>
						<div class="pageIcon"><?php echo $pageIcon;?></div>
					</div>
			</div>
		</div> <!-- END id="PageOveraly" -->

		<div id="Showcase">
			<div id="ShowcaseContent">
				<div class="contentArea">
					<h2 class="pageTagLine"><?php echo $subTitle; ?></h2>
				</div>
			</div>
		</div> <!-- END id="Showcase" -->

		<div id="MainPage">
			<div id="MainPageContent">
				<div class="contentArea">
					
					<div class="breadcrumbs" <?php  if ($hideBreadcrumbs) { echo 'style="background: none;"'; } ?>>
						<?php  if (!$hideBreadcrumbs) { show_breadcrumbs(); } ?>
					</div>
					
					<div class="two_third">
						<?php 
						// check for page content
						query_posts('page_id='.$post->ID);
						
						// Print content from the page
						if (have_posts()) : 
						while (have_posts()) : the_post(); 
							if (get_the_excerpt() != '') {
								the_content('More Information...');
								echo '<p class="clear">&nbsp;</p>';
							}
						endwhile;
						endif;

						// query posts for this blog page
						query_posts(array('category__not_in' => $excludeCategories, 'paged'=>$paged));

						// loop through the posts
						if ( have_posts() ) : 
							while ( have_posts() ) : the_post();
							
								// get the post image
								$thisImg = showImage(593, 199, get_the_title(), 'blog');
					
								?>
								<div class="blogPost">
								
									<div class="blogPostInfo">
										<span class="postComments"><?php comments_popup_link('Comments', '1 comment', '% comments'); ?></span>
										<?php 
										// post date
										if (get_theme_var('postsShowDate') !== '' ) {
											echo '<span class="postDate">'. get_the_time('M') .' '. get_the_time('j') .', '. get_the_time('Y') .'</span>';
										 	echo '&nbsp; | &nbsp;';
										} 
										// Author name
										if (get_theme_var('postsShowAuthor') !== '' ) { ?>
											<span class="postAuthor">Posted by <?php the_author_posts_link(); ?> in </span>
											<?php 
										} ?>
										<span class="postCategories"><?php the_category(', ') ?></span>
									</div>
									<?php
									if ( $thisImg['showImage'] ) { ?>
										<a href="<?php echo get_permalink() ?>" class="imgLarge iconDoc">
											<?php echo $thisImg['full']; ?>
											<span class="imgFrame"></span>
										</a>
									<?php } ?>

									
									<h2 onclick="document.location.href='<?php echo get_permalink(); ?>'" style="cursor:pointer;" class="postTitle"><?php the_title(); ?></h2>
					
									<p><?php echo str_replace(' [...]', '...', get_the_excerpt()); ?></p>
									<p><button type="button" onclick="document.location.href='<?php echo get_permalink() ?>'" class="btn">Read more</button></p>
									
								</div>
									
								<?php
							endwhile; 
						endif; // End while have_posts() ?>
						
						
						<div class="clear"></div>
					
						<?php get_pagination(); ?>
						
					</div> <!-- End class="two_third" -->

					<?php get_sidebar(); ?>
					
					<!-- End of Content -->
					<div class="clear"></div>
					
<?php get_footer(); ?>
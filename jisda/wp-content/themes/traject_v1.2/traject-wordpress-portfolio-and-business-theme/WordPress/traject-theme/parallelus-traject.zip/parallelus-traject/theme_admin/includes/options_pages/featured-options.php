<?php

#==================================================================
#
#	Display control panel options for Featured Content (home page)
#
#==================================================================

global $themePath;
include_once("featured-setup-options.php");
?>

<script src="<?php echo bloginfo('template_url'); ?>/theme_admin/js/jquery-1.4.min.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" src="<?php echo bloginfo('template_url'); ?>/theme_admin/js/sortMenu.js"></script>
<script type="text/javascript"> var $j = jQuery.noConflict(); </script>
<script type="text/javascript">
	// launches help file
	function openHelp(section) {
		window.open('<?php echo $themePath; ?>theme_admin/readme.html#'+section,'help','width=750,height=500,scrollbars=yes,resizable=yes');
	}
</script>
<link rel="stylesheet" type="text/css" href="<?php echo bloginfo('template_url'); ?>/theme_admin/css/styles.css" />
<link rel="stylesheet" type="text/css" href="<?php echo bloginfo('template_url'); ?>/theme_admin/css/sortable-lists.css" />
<div class="wrap">

	<h2><?php echo $themeTitle; ?> - Theme Settings</h2>

	<?php
	$the_Prefix = "Featured"; // used to label all the saved options (and for quickly applying to other options pages
	
	// save options to database (on submit)
	if (isset($_POST['save_theme_options'])) :
	
		// convert to and store setup options 
		parse_str($_POST[$the_Prefix.'-Options'], $all_Options);
		
		foreach ($options as $value) {     
			update_option($value['id'], $all_Options[$value['id']]);
		}
		
		// convert to and store array 
		parse_str($_POST[$the_Prefix.'-ItemLevels'], $all_Levels);
		update_option($shortname.$the_Prefix.'-ItemLevels', $all_Levels);
		
		// convert to and store array 
		parse_str($_POST[$the_Prefix.'-ItemValues'], $all_Values);
		update_option($shortname.$the_Prefix.'-ItemValues', $all_Values);

		// display success message
		echo '<div id="message" class="updated fade"><p><strong>Updated Successfully</strong></p></div>';
		
	endif;
	
	
	// Start printing page content
	
	// call title function
	options_title(array('name'=>'Featured Content'));
	
	// the default options
	echo '<form method="post" action="" id="optionsForm">';
	
		// load the function type for this option
		foreach ($options as $value) { 
			if (function_exists('options_'.$value['format'])) {
				// calls the specific function (i.e., options_start($value) )
				call_user_func('options_'.$value['format'], $value);
			}
		}
		
	echo '</form>';
	
	// middle buttons
	echo '<p>Add items below to create a scrolling featured content area on the home page.</p>';
	echo '<input type="button" class="button-secondary autowidth" style="float:right;" onClick="openHelp(\'featured\');" value="Theme Help" />';
	echo '<input type="button" name="save_theme_options" class="button-primary autowidth" onClick="saveMenu();" value="Save Changes" style="float:left; margin-right: 2em;" />';
	echo '<input type="button" class="button-secondary autowidth" style="float:left;" onClick="addMenuItem(true);" value="Add New Item" />';
	echo '<p style="clear:both; margin: 0;">&nbsp;</p>';
	
	// start the main table	
	echo '<form method="post" action="" id="editForm">';
	echo '<div class="themeTableWrapper">';
	echo '<table cellspacing="0" class="widefat themeTable">';
	echo '<thead><tr>';
	echo '<th scope="row">Featured Items</th>';
	echo '</tr></thead><tbody>';
	?>
	
	<tr>
		<td>
			<div>
				<ul id="SortList">
					<?php
					// output the menu as an unordered list
					$_Levels = get_option($shortname.$the_Prefix.'-ItemLevels');
					$_Values = get_option($shortname.$the_Prefix.'-ItemValues');
					
					if(!empty($_Levels) && is_array($_Levels)) {
						buildList($_Levels['SortList'], $_Values);
					}
					?>
				</ul>
			</div>
		</td>
	</tr>
	
	<?php
	
	// call table end function
	options_end(NULL);
	echo '</form>';
	echo '<p class="submit"><input type="button" name="save_theme_options" class="button-primary autowidth" onClick="saveMenu();" value="Save Changes" /></p>';
	
	?>
	<br/>
	
	<form method="post" action="" id="submitForm" style="display:none;">
		<input type="hidden" name="<?php echo $the_Prefix; ?>-Options" id="<?php echo $the_Prefix; ?>-Options" value="" />
		<input type="hidden" name="<?php echo $the_Prefix; ?>-ItemLevels" id="<?php echo $the_Prefix; ?>-ItemLevels" value="" />
		<input type="hidden" name="<?php echo $the_Prefix; ?>-ItemValues" id="<?php echo $the_Prefix; ?>-ItemValues" value="" />
		<input type="hidden" value="true" name="save_theme_options" />
	</form>
	
	<ul style="display:none;" id="sample-<?php echo $the_Prefix; ?>-item">
		<?php 
		// Default options (for new items)
		$_Defaults = array(
			$the_Prefix .'-#-title'			=>	'',
			$the_Prefix .'-#-linkType'		=>	'page',
			$the_Prefix .'-#-linkURL'		=>	'http://'	
		);
		
		// create the template li used for inserting new items
		buildList(array('id' => '#'), $_Defaults);
		?>
	</ul>
	
	<ul style="display:none;" id="separator-<?php echo $the_Prefix; ?>-item">
		<?php 
		// create the template separator used for inserting a separator
		buildList(array('id' => '#'), array($the_Prefix.'-#-linkTitle' => $the_Prefix.'-separator'));
		?>
	</ul>
	
	<?php
	
	// a function to print the items
	function buildList($theArray, $theValues = array()) {
		
		$the_Prefix = "Featured";
		
		foreach ($theArray as $key => $value) {
		
			// get variables setup
			$id = $value['id'];
			$options = $theValues;
			
		
			$_LinkCategory = "";
			$_LinkURL = "";
			$_LinkPage = "";
			$_SelectCategory = "display: none;";
			$_SelectURL = "display: none;";
			$_SelectPage = "display: none;";

		
			switch ($options[$the_Prefix.'-'. $id .'-linkType']) {
		
				case 'category':
					$_LinkCategory = "checked";
					$_SelectCategory = "display: block;";
					break;
		
				case 'url':
					$_LinkURL = "checked";
					$_SelectURL = "display: block;";
					break;
		
				default:
					$_LinkPage = "checked";
					$_SelectPage = "display: block;";
					break;
			}
			?>
			
			<li id="<?php echo $the_Prefix; ?>-item-<?php echo $id ?>" rel="<?php echo $id ?>" class="isSortable li-item noNesting">
				<div class="sortItem">
					<table cellpadding="0" cellspacing="0" width="100%">
						<tbody>
							<tr>
								<td class="handle"><div></div></td>
								<td width="400">
									<table cellpadding="3" cellspacing="0">
										<tbody>
											<tr>
												<td style="padding: 3px;"><strong>Image URL: </strong></td>
												<td style="padding: 3px;">
													<input type="text" name="<?php echo $the_Prefix; ?>-<?php echo $id ?>-image" value="<?php echo htmlspecialchars(stripslashes($options[$the_Prefix.'-'. $id .'-image'])) ?>" class="<?php echo $the_Prefix; ?>-image" alt="Image Path" style="width: 300px;" />
												</td>
											</tr>
											<tr>
												<td style="padding: 3px;"><strong>Title: </strong></td>
												<td style="padding: 3px;">
													<input type="text" name="<?php echo $the_Prefix; ?>-<?php echo $id ?>-title" value="<?php echo htmlspecialchars(stripslashes($options[$the_Prefix.'-'. $id .'-title'])) ?>" class="<?php echo $the_Prefix; ?>-title" alt="Title" style="width: 300px;" />
												</td>
											</tr>
											<tr>
												<td style="padding: 3px;"><strong>Link: </strong></td>
												<td style="padding: 3px;">
													<label for="<?php echo $the_Prefix; ?>-LinkTypePage-<?php echo $id ?>" class="<?php echo $_LinkPage ?>">
														<input type="radio" name="<?php echo $the_Prefix; ?>-<?php echo $id ?>-linkType" id="<?php echo $the_Prefix; ?>-LinkTypePage-<?php echo $id ?>" value="page" <?php echo $_LinkPage ?> />&nbsp;Page
													</label>
													<label for="<?php echo $the_Prefix; ?>-LinkTypeCategory-<?php echo $id ?>" class="<?php echo $_LinkCategory ?>">
														<input type="radio" name="<?php echo $the_Prefix; ?>-<?php echo $id ?>-linkType" id="<?php echo $the_Prefix; ?>-LinkTypeCategory-<?php echo $id ?>" value="category" <?php echo $_LinkCategory ?> />&nbsp;Category
													</label>
													<label for="<?php echo $the_Prefix; ?>-LinkTypeURL-<?php echo $id ?>" class="<?php echo $_LinkURL ?>">
														<input type="radio" name="<?php echo $the_Prefix; ?>-<?php echo $id ?>-linkType" id="<?php echo $the_Prefix; ?>-LinkTypeURL-<?php echo $id ?>" value="url" <?php echo $_LinkURL ?> />&nbsp;URL
													</label>
												</td>
											</tr>
											<tr>
												<td style="padding: 3px;">&nbsp;</td>
												<td style="padding: 0 3px;">
													<?php 
													// print page drop down
													_select_option(
														array(
															'name' => $the_Prefix.'-'. $id .'-linkPage',
															'id' => $the_Prefix.'-LinkPage-'. $id ,
															'style' => $_SelectPage,
															'selected' => $options[$the_Prefix.'-'. $id .'-linkPage'],
															'default' => 'Choose a page...',
															'options' => $GLOBALS['pageList']
														)
													);
													// print category drop down
													_select_option(
														array(
															'name' => $the_Prefix.'-'. $id .'-linkCategory',
															'id' => $the_Prefix.'-LinkCategory-'. $id ,
															'style' => $_SelectCategory,
															'selected' => $options[$the_Prefix.'-'. $id .'-linkCategory'],
															'default' => 'Choose a category...',
															'options' =>  $GLOBALS['categoryList']
														)
													);
													?>
													<input type="text" name="<?php echo $the_Prefix; ?>-<?php echo $id ?>-linkURL" value="<?php echo htmlspecialchars(stripslashes($options[$the_Prefix.'-'. $id .'-linkURL'])) ?>" id="<?php echo $the_Prefix; ?>-LinkURL-<?php echo $id ?>" class="<?php echo $the_Prefix; ?>-Link" style="width: 300px; <?php echo $_SelectURL ?>" >
												</td>
											</tr>
										</tbody>
									</table>
								</td>
								<td style="white-space: nowrap;" align="left" width="350">
									<table cellpadding="3" cellspacing="0">
										<tbody>
											<tr>
												<td style="padding: 3px;"><strong>Description: </strong></td>
											</tr>
											<tr>
												<td style="padding: 3px;">
													<textarea type="text" name="<?php echo $the_Prefix; ?>-<?php echo $id ?>-description" class="<?php echo $the_Prefix; ?>-Desc" alt="Image Description" style="width: 350px; height: 90px;"><?php echo htmlspecialchars(stripslashes($options[$the_Prefix.'-'. $id .'-description'])) ?></textarea>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
								<td align="right">
									<!--Delete button-->
									<div class="button-secondary delete-item">Delete</div>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				
				<?php
				// check for child elements
				if (is_array($value['children'])) {
					echo "<ul>";
					buildList($value['children'], $options);
					echo "</ul>";
				}
				
			echo "</li>";
			
		} // end foreach item
		
	} // END - function buildList()
	
	
	// pages and categories select boxes
	function _select_option($value) {
	
		echo '<select class="'. $the_Prefix .'-Link" name="'. $value['name'] .'" id="'. $value['id'] .'" style="'. $value['style'] .'">';
			echo '<option value="">'. $value['default'] .'</option>';
			foreach ($value['options'] as $key=>$option) { 
				echo '<option value="'. $key .'"'; 
				if ( $value['selected'] == $key ) { 
					echo ' selected="selected"'; 
				}
				echo '>'. $option .'</option>';
			}
		echo '</select>';
	}
	
	
	// transition type select boxe
	function _transition_option($value, $id) {
		foreach ($value['options'] as $key=>$option) {
			echo '<option value="'. $key .'"'; 
			if ( $value['selected'] == $key ) { 
				echo ' selected="selected"'; 
			}
			echo '>'. $option .'</option>';
		}
	}
	?>
	
</div>


<script type="text/javascript">

// array to track all nested item id's
var nestedListIds = [];

// creates draggable nested item menu
function initializeMenu() {
	// convert into sortable list
	$j('#SortList').NestedSortable({
		accept: 'isSortable',
		noNestingClass: "noNesting",
		opacity: 0.8,
		helperclass: 'helper',
		onChange: function(serialized) {
			$j('#<?php echo $the_Prefix; ?>-ItemLevels').val((serialized[0].hash));
		},
		onStart: function() {
			// prevents a horizontal scroll when dragging
			$j(document.body).css('overflow-x','hidden');
		},
		onStop: function() {
			// restors scrolling after draggin completes
			$j(document.body).css('overflow-x','auto');
		},
		autoScroll: true,
		handle: '.handle'
	})
	.find('li').each( function() {

		// add onclick other dynamic functions
		if (!this.hasClickEventHandlers) {
	
			var thisItem = $j(this);
			var n = thisItem.attr('rel');
			nestedListIds.push(parseInt(n)); // add the id to a list (used to prevent duplicates when editing)
			var linkOptions = $j("input[name='<?php echo $the_Prefix; ?>-"+n+"-linkType']");
			var deleteButton = thisItem.find(".delete-item:first");

			// add click event for link options
			linkOptions.click( function() {

				var p = $j('#<?php echo $the_Prefix; ?>-LinkPage-'+n);
				var c = $j('#<?php echo $the_Prefix; ?>-LinkCategory-'+n);
				var u = $j('#<?php echo $the_Prefix; ?>-LinkURL-'+n);
				
				// toggle display of page/category/url field
				($j(this).val() == 'page') 		? p.css('display','block') : p.css('display','none');
				($j(this).val() == 'category') 	? c.css('display','block') : c.css('display','none');
				($j(this).val() == 'url') 		? u.css('display','block') : u.css('display','none');

				// mark active label with "checked" class
				$j(this + ':not(:checked)').parent('label').removeClass('checked');
				$j(this + ':checked').parent('label').addClass('checked');

			});

			// add click event for delete button
			deleteButton.click( function() {
				if (confirm("Are you sure you want to delete this item?")) {
					thisItem.remove();
				} else {
					return false;
				}
			});
			
			this.hasClickEventHandlers = true;
		}
	});
}

// inserts a new menu item
function addMenuItem(itemType) {

	var count = $j('#SortList').find('li').length,
		menuItem = $j('#sample-<?php echo $the_Prefix; ?>-item li'),
		//separator = $j('#separator-<?php echo $the_Prefix; ?>-item li'),
		template;

	if (itemType == 'separator') {
		// adding a separator
		template  = separator;
	} else {
		// adding a menu item
		template  = menuItem;
	}

	// prevent duplicate id's by checking agains all current ones	
	var newID = count;
	
	while ($j.inArray(newID, nestedListIds) != -1 ) {
		newID++;
	}
	
	template.clone()
		.attr('id',template.attr('id').replace('#',newID))
		.attr('rel',newID)
		.find('*').each( function() {
			var attrId = $j(this).attr('id'),
			attrName = $j(this).attr('name'),
			attrFor = $j(this).attr('for');
			if (attrId) $j(this).attr('id', attrId.replace('#',newID));
			if (attrName)$j(this).attr('name', attrName.replace('#',newID));
			if (attrFor)$j(this).attr('for', attrFor.replace('#',newID));
		}).end()
	.prependTo($j('#SortList'));

	// re-initialize sorting to include new item
	initializeMenu();
}


// save the menu options to the database
function saveMenu() {

	// get the individual item options
	$j('#<?php echo $the_Prefix; ?>-Options').val($j('#optionsForm').serialize());

	// get the individual item options
	$j('#<?php echo $the_Prefix; ?>-ItemValues').val($j('#editForm').serialize());

	// get the list in it's sorted order for creating menus and sub-menus
	$j('#<?php echo $the_Prefix; ?>-ItemLevels').val(jQuery.iNestedSortable.serialize('SortList').hash);
	$j('#submitForm').submit();

}


jQuery(document).ready(function() {
	// activate the sortable list
	initializeMenu();
});	

</script>


<?php get_header();


	// Display a list posts from categories for the home page
	$category = theme_var('homeContentCategory','return');	
	if ($category) {
		query_posts(array('category__in' => $category, 'paged'=>$paged));
	}
	?>
	<div class="two_third">
	
		<?php 
		if ( have_posts() ) : 
			while ( have_posts() ) : the_post();
			
				// get the post image
				$thisImg = showImage(593, 199, get_the_title(), 'blog');
	
				?>
				<div class="blogPost">
				
					<div class="blogPostInfo">
						<span class="postComments"><?php comments_popup_link('Comments', '1 comment', '% comments'); ?></span>
						<?php if (get_theme_var('postsShowDate') !== '' ) {
							echo '<span class="postDate">'. get_the_time('M') .' '. get_the_time('j') .', '. get_the_time('Y') .'</span>';
						} ?>
						 &nbsp; | &nbsp; 
						<?php
						if (get_theme_var('postsShowAuthor') !== '' ) { ?>
							<span class="postAuthor">Posted by <?php the_author_posts_link(); ?> in </span>
							<?php 
						} ?>
						<span class="postCategories"><?php the_category(', ') ?></span>
					</div>
					<?php
					if ( $thisImg['showImage'] ) { ?>
						<a href="<?php echo get_permalink() ?>" class="imgLarge iconDoc">
							<?php echo $thisImg['full']; ?>
							<span class="imgFrame"></span>
						</a>
					<?php } ?>
					
					<h2 onclick="document.location.href='<?php echo get_permalink(); ?>'" style="cursor:pointer;" class="postTitle"><?php the_title(); ?></h2>
	
					<p><?php echo str_replace(' [...]', '...', get_the_excerpt()); ?></p>
					<p><button type="button" onclick="document.location.href='<?php echo get_permalink() ?>'" class="btn">Read more</button></p>
					
				</div>
					
				<?php
			endwhile; 
		endif; // End while have_posts() ?>
		
		<!-- End of Content -->
		<div class="clear"></div>
	
		<?php get_pagination(); ?>
		
	</div>

	<div class="one_third last">
		<div class="sidebar">
			<div class="sidebarBox-1">
				<div class="sidebarBox-2">
	
					<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Homepage Sidebar')) : endif; ?>
	
				</div>
			</div>
		</div> <!-- END class="sidebar" -->
		
	</div>
	
	<!-- End of Content -->
	<div class="clear"></div>
		
	<?php


// reset query
wp_reset_query();

// include WP footer
get_footer(); ?>